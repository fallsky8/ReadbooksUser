package com.readbooks.cartdao;

import com.readbooks.cartvo.CartVO;

public interface CartDAO {

	public int cartInsert(CartVO cart);

	public int cartDelete(CartVO cart);

}
